# Privacy Policy

We respect your privacy. This application does not collect personal data without consent. Any data collected will be used solely for improving user experience and will not be shared with third parties.

## Data We Collect
- Minimal app usage analytics

## How We Use Data
To improve the app's functionality and user experience.
