# Terms of Service

By using this application, you agree to abide by the following terms:

1. This app is provided "as is" without any guarantees.
2. Users must not use the app for illegal purposes.
3. We reserve the right to modify these terms at any time.
